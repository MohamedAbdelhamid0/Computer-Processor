Simple Computer Processor Project
Made By: Mohamed Ahmed Abdelhamid
Course of Project: Computer Organization and Architecture.
For other Projects -----> GITHUB: https://www.github.com/MohamedAbdelhamid0
Logic Design (ALU) Project ---->  https://www.github.com/MohamedAbdelhamid0

Phase 1 Folder Contents:

Register File
ALU
Datapath File that connectes the Register File to the ALU
